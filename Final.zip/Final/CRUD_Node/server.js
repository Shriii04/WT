const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const fs = require('fs');

const PORT = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));

let students = [];

app.get('/get-students', (req, res) => {
    res.json(students);
});

app.post('/add-student', (req, res) => {
    const studentData = req.body;
    studentData.id = generateUniqueId();
    students.push(studentData);
    res.json({ message: 'Student added successfully.', student: studentData });
});

app.put('/update-student/:id', (req, res) => {
    const studentId = req.params.id;
    const updatedData = req.body;

    const index = students.findIndex((student) => student.id === studentId);

    if (index !== -1) {
        students[index] = {...students[index], ...updatedData };
        res.json({ message: 'Student updated successfully.', student: students[index] });
    } else {
        res.status(404).json({ error: 'Student not found.' });
    }
});

app.delete('/delete-student/:id', (req, res) => {
    const studentId = req.params.id;
    students = students.filter((student) => student.id !== studentId);
    res.json({ message: 'Student deleted successfully.' });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

function generateUniqueId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}