const fs = require('fs');

// Reading from a file
fs.readFile('example.txt', 'utf8', (err, data) => {
    if (err) {
        console.error('Error reading file:', err);
        return;
    }
    console.log('File content:', data);
});

// Writing to a file
// const contentToWrite = 'Hello, this new content.';
// fs.writeFile('example.txt', contentToWrite, 'utf8', (err) => {
//     if (err) {
//         console.error('Error writing to file:', err);
//         return;
//     }
//     console.log('File written successfully!');
// });

// Deleting a file
// fs.unlink('example.txt', (err) => {
//     if (err) {
//         console.error('Error deleting file:', err);
//         return;
//     }
//     console.log('File deleted successfully!');
// });
