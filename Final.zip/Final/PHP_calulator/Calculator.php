<!DOCTYPE html>
<html>
<head>
    <title>PHP Calculator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }

        h2 {
            color: #007BFF;
        }

        .calculator {
            width: 350px;
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .calculator input[type="button"] {
            width: 45px;
            height: 45px;
            font-size: 18px;
            color: #007BFF;
            background-color: #f8f9fa;
            border: 1px solid #ccc;
            cursor: pointer;
            border-radius: 5px;
            margin: 3px;
            transition: background-color 0.2s, transform 0.2s;
        }

        .calculator input[type="button"]:hover {
            background-color: #007BFF;
            color: #fff;
            transform: scale(1.1);
        }

        .calculator input[type="button"]:active {
            transform: scale(0.95);
        }

        .calculator input[type="text"] {
            width: 100%;
            height: 40px;
            font-size: 18px;
            text-align: right;
            margin-bottom: 10px;
            color: #007BFF;
            border: none;
            background-color: #f0f0f0;
            padding: 5px;
            border-radius: 5px;
        }

        #equal {
            width: 100%;
            font-size: 18px;
            border: none;
            background-color: #28a745;
            color: #fff;
            cursor: pointer;
            border-radius: 5px;
            padding: 10px;
            transition: background-color 0.2s, transform 0.2s;
        }

        #equal:hover {
            background-color: #218838;
        }

        #equal:active {
            transform: scale(0.95);
        }

        .calculator input[type="button"].scientific {
            background-color: #007BFF;
            color: #fff;
        }

        .calculator input[type="button"].scientific:hover {
            background-color: #0056b3;
        }

        .calculator input[type="button"].scientific:active {
            transform: scale(0.95);
        }
    </style>
</head>
<body>

<center><h2>PHP Scientific Calculator</h2></center>

<div class="calculator">
    <form method="post" action="">
        <input type="text" name="result" id="result" placeholder="0" readonly>
        <br>
        <!-- ... (previous number and basic operation buttons) ... -->
        <input type="button" value="1" onclick="appendValue('1')">
        <input type="button" value="2" onclick="appendValue('2')">
        <input type="button" value="3" onclick="appendValue('3')">
        <input type="button" value="+" onclick="appendValue('+')">
	<input type="button"  value="√" onclick="appendValue('sqrt(')">
	<input type="button"  value="cos" onclick="appendValue('cos(')">
        <br>
        <input type="button" value="4" onclick="appendValue('4')">
        <input type="button" value="5" onclick="appendValue('5')">
        <input type="button" value="6" onclick="appendValue('6')">
        <input type="button" value="-" onclick="appendValue('-')">
	<input type="button"  value="x^2" onclick="appendValue('**2')">
	<input type="button"  value="tan" onclick="appendValue('tan(')">
        <br>
        <input type="button" value="7" onclick="appendValue('7')">
        <input type="button" value="8" onclick="appendValue('8')">
        <input type="button" value="9" onclick="appendValue('9')">
        <input type="button" value="*" onclick="appendValue('*')">
	<input type="button"  value="x^y" onclick="appendValue('**')">
	<input type="button"  value="log" onclick="appendValue('log(')">
        <br>
        <input type="button" value="0" onclick="appendValue('0')">
        <input type="button" value="." onclick="appendValue('.')">
        <input type="button" value="/" onclick="appendValue('/')">
        <input type="button" value="C" onclick="clearResult()">
	<input type="button"  value="sin" onclick="appendValue('sin(')">
        <input type="button"  value="ln" onclick="appendValue('ln(')">
        <br>
	
        <input type="button"  value="(" onclick="appendValue('(')">
        <input type="button"  value=")" onclick="appendValue(')')">
        <br><br>
        <input id="equal" type="submit" value="=">
    </form>
</div>

<script>
    // Function to append value to the result input
    function appendValue(value) {
        document.getElementById("result").value += value;
    }

    // Function to clear the result input
    function clearResult() {
        document.getElementById("result").value = '';
    }
</script>
<?php
// Function to perform the calculation
function calculate($expression)
{
    try {
        eval('$result = ' . $expression . ';');
        return $result;
    } catch (Throwable $e) {
        return "Error";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $expression = $_POST['result'];

    // Calculate the result
    $result = calculate($expression);

    echo "<div class='calculator'>";
    echo "<h3>Result: $result</h3>";
    echo "</div>";
}
?>

</body>
</html>

