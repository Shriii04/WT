<?php
// Check if a value is submitted
if (isset($_POST['inputValue'])) {
    // Get the input value
    $inputValue = $_POST['inputValue'];

    // Set the cookie with the input value
    setcookie('user_input', $inputValue, time() + (86400 * 30), '/'); // Cookie lasts for 30 days

    // Redirect to the same page to display the stored cookie value
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Check if the cookie is set
if (isset($_COOKIE['user_input'])) {
    $storedValue = $_COOKIE['user_input'];
} else {
    $storedValue = "No value stored.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cookie Management Example</title>
</head>
<body>
    <h1>Cookie Management Example</h1>
    <p>Stored Value: <?php echo $storedValue; ?></p>
    
    <form method="post" action="">
        <label for="inputValue">Input Value:</label>
        <input type="text" name="inputValue" id="inputValue" required>
        <button type="submit">Submit</button>
    </form>
</body>
</html>