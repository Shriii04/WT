<?php

session_start();

if (isset($_POST['inputValue'])) {
    // Get the input value
    $inputValue = $_POST['inputValue'];

    $_SESSION['user_input'] = $inputValue;

   
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

if (isset($_SESSION['user_input'])) {
    $storedValue = $_SESSION['user_input'];
} else {
    $storedValue = "No value stored.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Session Management Example</title>
</head>
<body>
    <h1>Session Management Example</h1>
    <p>Stored Value: <?php echo $storedValue; ?></p>
    
    <form method="post" action="">
        <label for="inputValue">Input Value:</label>
        <input type="text" name="inputValue" id="inputValue" required>
        <button type="submit">Submit</button>
    </form>
</body>
</html>