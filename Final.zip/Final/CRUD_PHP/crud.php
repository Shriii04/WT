<!DOCTYPE html>
<html>

<head>
    <title>CRUD Operations</title>
</head>

<body>
    <h1>CRUD Operations</h1>

    <?php
    // Database connection settings
    $servername = "localhost";
    $username = "root";
    $password = "Shobit2021@vit";
    $database = "form";

    // Create a connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Create (Insert) operation
    if (isset($_POST['create'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];

        // Use prepared statement to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO users (username, email) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $email);

        if ($stmt->execute()) {
            echo "Record created successfully";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }

    // Read operation
    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>ID</th><th>Username</th><th>Email</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["id"] . "</td><td>" . $row["username"] . "</td><td>" . $row["email"] . "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "No records found";
    }

    // Update operation
    if (isset($_POST['update'])) {
        $id = $_POST['id'];
        $newUsername = $_POST['new_username'];
        $newEmail = $_POST['new_email'];

        $stmt = $conn->prepare("UPDATE users SET username=?, email=? WHERE id=?");
        $stmt->bind_param("ssi", $newUsername, $newEmail, $id);

        if ($stmt->execute()) {
            echo "Record updated successfully";
        } else {
            echo "Error updating record: " . $stmt->error;
        }

        $stmt->close();
    }

    // Delete operation
    if (isset($_GET['delete'])) {
        $id = $_GET['delete'];

        $stmt = $conn->prepare("DELETE FROM users WHERE id=?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo "Record deleted successfully";
        } else {
            echo "Error deleting record: " . $stmt->error;
        }

        $stmt->close();
    }

    // Close the database connection
    $conn->close();
    ?>

    <!-- Create (Insert) Form -->
    <h2>Create Record</h2>
    <form method="POST">
        <input type="text" name="username" placeholder="Username">
        <input type="email" name="email" placeholder="Email">
        <button type="submit" name="create">Create</button>
    </form>

    <!-- Update Form -->
    <h2>Update Record</h2>
    <form method="POST">
        <input type="number" name="id" placeholder="ID">
        <input type="text" name="new_username" placeholder="New Username">
        <input type="email" name="new_email" placeholder="New Email">
        <button type="submit" name="update">Update</button>
    </form>

    <!-- Delete Form -->
    <h2>Delete Record</h2>
    <form method="GET">
        <input type="number" name="delete" placeholder="ID to Delete">
        <button type="submit">Delete</button>
    </form>
</body>

</html>
